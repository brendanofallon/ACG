	 
	
			Primo - Business / Corporate xHTML Template
	
	======================================================================================

	Thank you for buying this template!
	

	1. The help file for the html website is in the /03.documentation folder.

	   You should read it before working with this product as it offers a very useful
	   overview on it's folder structure, general page layout, plugins and script usage.
        

	2. If you need assistance with a problem and you don't find
           the solution in the documentation, just let me know and I'd be happy to help!

           Please send me a message through my profile page:
	   
	   http://themeforest.net/user/bitpub

	   (contact form is in the bottom right of page if you are logged in) 	
	
